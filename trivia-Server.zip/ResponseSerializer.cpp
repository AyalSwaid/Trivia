#include "ResponseSerializer.h"

#include <stdlib.h>

ResponseSerializer::ResponseSerializer()
{
}


ResponseSerializer::~ResponseSerializer()
{
}

std::string ResponseSerializer::serializeResponse(responses::RequestResult res)
{
	std::string code = numToBin(res.response, 1);
	std::string data;
	std::string length_string;

	int length = 0;

	if (res.data.empty())
	{
		length_string = numToBin(length, 0);
		return code + length_string;
	}

	length = res.data.size();
	data = txtToBin(res.data);

	length_string = numToBin(length, 0);

	return code + length_string + data;
}

/*
	function get an integer and return it in its binary value in a string.
*/
std::string ResponseSerializer::numToBin(int n, bool isCode)
{// from google :D
	std::string r;
	while (n != 0) { r = (n % 2 == 0 ? "0" : "1") + r; n /= 2; }

	if (isCode)
	{
		while (r.size() != 8)
		{
			r = "0" + r;
		}
	}
	else
	{
		while (r.size() != 32)
		{
			r = "0" + r;
		}
	}
	return r;
}

/*
	function get a string and return it converted to binary.
*/
std::string ResponseSerializer::txtToBin(std::string str)
{
	std::string binString;

	for (int i = 0; i < str.size(); i++)
	{
		binString += chrToBin(str[i]);
	}

	return binString;
}

/*
	function get a char and return it in its binary ascii value in string.
*/
std::string ResponseSerializer::chrToBin(char i)
{
	char buffer[8]; //the variable you will store i's new value (binary value) in
	
	_itoa_s(i, buffer, 2);

	std::string buf(buffer);

	while (buf.size() % 8 != 0)
	{
		buf = "0" + buf;
	}

	return buf;
}