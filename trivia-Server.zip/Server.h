#pragma once
#pragma comment (lib, "ws2_32.lib")

#include "WSAInitializer.h"
#include "Server.h"
#include <iostream>
#include <exception>
#include "Communicator.h"
#include "IDatabase.h"

class Server
{
public:
	Server();
	~Server();

	void run();

private:
	IDatabase m_database;
};

