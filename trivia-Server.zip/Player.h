#pragma once

#include <string>

class Player
{
public:
	Player(std::string nname, int NOG, int RA, int WA, int AT);
	Player(std::string nname);
	Player();
	~Player();

	std::string name();

	unsigned int numOfGames;
	unsigned int rightAnswers;
	unsigned int wrongAnswers;
	int averageTime;

	Player& operator+=(const Player& other);

private:
	std::string _name;
};

