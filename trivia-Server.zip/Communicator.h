#pragma once
#include <vector>
#include <deque>
#include <exception>
#include <iostream>
#include <string>
#include <thread>

#include <WinSock2.h>
#include <Windows.h>

#include "constants.h"
#include "menuRequestHandler.h"

typedef std::pair<SOCKET, requests::Request> client;

#define PORT 8876

class Communicator
{
public:
	Communicator();
	~Communicator();
	
	void serve();
	

private:
	void bindAndListen(int port);
	void accept();
	void clientHandler(SOCKET client_socket);
	void handleRequests();// deal with the client's request.
	void resp(client cli, std::string response);
	void deleteUser(std::string name);// delete a user from _onlineUsers.

	// clients server is FIFO - first client in, first client out.
	std::deque<client> _clients;
	std::vector<std::string> _onlineUsers;
	SOCKET _serverSocket;
	menuRequestHandler _menuManager;
};

