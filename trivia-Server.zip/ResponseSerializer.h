#pragma once

#include "constants.h"

class ResponseSerializer
{
public:
	ResponseSerializer();
	~ResponseSerializer();

	std::string serializeResponse(responses::RequestResult res);

private:
	std::string numToBin(int n, bool isCode);
	std::string txtToBin(std::string str);
	std::string chrToBin(char i);
};

