#include "Server.h"



Server::Server()
{
}


Server::~Server()
{
}

void Server::run()
{
	try
	{
		WSAInitializer wsaInit;
		Communicator server;
		server.serve();
	}
	catch (std::exception& e)
	{
		std::cout << "Error occured: " << e.what() << std::endl;
	}
}