#include "Server.h"

int main()
{
	try
	{
		Server myServer;
		myServer.run();
	}
	catch (std::exception& e)
	{
		std::cout << e.what();
		getchar();
	}
	return 0;
}