#pragma warning(disable : 4996)

#include <string.h>

#include "IDatabase.h"
#include "callBacks.h"
#include <algorithm>

sqlite3* db;

#define SQL_FILE_PATH "DBtrivia.sqlite"// may cause error becase the .db

IDatabase::IDatabase()
{
	open();
}


IDatabase::~IDatabase()
{
	close();
}

// open the access to the database.
bool IDatabase::open()
{
	int res = sqlite3_open(SQL_FILE_PATH, &db);
	if (res != SQLITE_OK)
	{
		db = nullptr;
		cout << "Failed to open DB" << endl;
		return false;
	}
	return true;
}

void IDatabase::close()
{
	sqlite3_close(db);
	db = nullptr;
}

bool IDatabase::is_exist(requests::User user)
{
	/*
		check if the user exist in the database.
		input: requests::User.
		output: bool.
	*/
	users.clear();

	string getUsers = "SELECT * FROM Users WHERE name = '" + user._name +
		"';";

	char *errMsg = nullptr;


	int rc = sqlite3_exec(db, getUsers.c_str(), forUsers, nullptr, &errMsg);
	
	return !users.empty();
}


bool IDatabase::signup(requests::User user)
{
	/*
		add user to the database(signup).
		input: requests::User.
		output: true --> ok, false --> error.
	*/
	string eml = "'" + user._email + "'";
	string pswrd = "'" + user._password + "'";
	string usrnm = "'" + user._name + "'";

	string addUser = "INSERT INTO Users (name, password, email) VALUES(" +
		usrnm + ", " + pswrd.c_str() + ", " + eml.c_str() + "');";
	
	char* errMsg = 0;
	int rc = sqlite3_exec(db, addUser.c_str(), nullptr, nullptr, &errMsg);

	addStatusRow(user._name);
	
	return rc != SQLITE_OK ? false : true;
}

Player IDatabase::getStatus(std::string name)
{
	/*
		get user's status from the db.
		input: std::string --> player name.
		output: Player.
	*/
	players.clear();
	name.erase(remove(name.begin(), name.end(), '\0'), name.end());
	string getStatus = "SELECT * FROM Status WHERE player_name = '" + name +
		"';";

	sqlite3_exec(db, getStatus.c_str(), forPlayers, nullptr, nullptr);

	return players[0];
}

void IDatabase::updateStatus(Player p)
{
	/*
		update the player status in the db.
		input: Player.
		output: void.
	*/
	string update = "UPDATE Status SET numberOfGames = " + std::to_string(p.numOfGames) +
		", rightAnswers = " + std::to_string(p.rightAnswers) +
		", wrongAnswers = " + std::to_string(p.wrongAnswers) +
		", averageTime = " + std::to_string(p.averageTime) +
		" WHERE player_name=" + p.name().c_str() + ";";

	char* errMSG = 0;
	int rc = sqlite3_exec(db, update.c_str(), nullptr, nullptr, &errMSG);

	if (rc != SQLITE_OK)
	{
		throw(std::exception(errMSG));
	}
}

std::map<std::string, int> IDatabase::getHighscores()
{
	/*
		get the highscores from the db.
		input: void.
		output: std::map<std::string, int>
	*/
	highScores.clear();

	string getBest5 = "SELECT player_name, rightAnswers FROM Status ORDER BY rightAnswers ASC LIMIT 5;";
	char* errMSG = 0;

	int rc = sqlite3_exec(db, getBest5.c_str(), forHighScores, nullptr, &errMSG);

	if (rc != SQLITE_OK)
	{
		throw(std::exception(errMSG));
	}

	return highScores;
}

std::vector<Question> IDatabase::getQuestions(int n)
{
	/*
		get the questions from the db.
		input: int n: number of questions.
		output: vector of Question.
	*/
	questions.clear();

	string getQuestns = "SELECT * FROM Questions LIMIT " + std::to_string(n) + ";";

	char* errMSG = 0;

	int rc = sqlite3_exec(db, getQuestns.c_str(), forQuestions, nullptr, &errMSG);

	if (rc != SQLITE_OK)
	{
		throw(std::exception(errMSG));
	}

	return questions;
}

void IDatabase::addStatusRow(std::string name)
{
	/*
		add a row to the Status table.
		input: std:string name: playerName
		output: void.
	*/
	string addRowToStatus = "INSERT INTO Status (player_name, numberOfGames, rightAnswers, wrongAnswers, averageTime) VALUES('" + name + "', 0, 0, 0, 0)";

	sqlite3_exec(db, addRowToStatus.c_str(), forQuestions, nullptr, nullptr);
}

std::string IDatabase::getPassword(std::string username)
{
	/*
		get the password of some user from the db.
		input: std:string name: username
		output: std:string: password.
	*/
	string getPasword = "SELECT password FROM Users WHERE name='" + username + "';";
	
	sqlite3_exec(db, getPasword.c_str(), forPassword, nullptr, nullptr);

	return pazword;
}