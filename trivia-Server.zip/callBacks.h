#pragma once
// here the functions that the database will use (by sqlite)
// and the results will be stored in the variables before the namespace.

#include <iostream>
#include <string>
#include <vector>

//#include "LoginManager.h"
#include "constants.h"
using std::string;

std::vector<requests::User> users;
std::vector<Player> players;
std::map<string, int> highScores;
std::vector<Question> questions;
string pazword;

int forUsers(void *data, int argc, char **argv, char **azColName)
{
	requests::User us;
	for (int i = 0; i < argc; i++)
	{
		if (string(azColName[i]) == "name")
		{
			us._name = argv[i];
		}
		else if (string(azColName[i]) == "password")
		{
			us._password = argv[i];
		}
		else if (string(azColName[i]) == "email")
		{
			us._email = argv[i];
		}
	}
	users.push_back(us);
	return 0;
}

int forPlayers(void *data, int argc, char **argv, char **azColName)
{
	std::string name;
	int NOG;
	int RA;
	int WA;
	int AT;

	for (int i = 0; i < argc; i++)
	{
		if (string(azColName[i]) == "player_name")
		{
			name = argv[i];
		}
		else if (string(azColName[i]) == "numberOfGames")
		{
			NOG = atoi(argv[i]);
		}
		else if (string(azColName[i]) == "rightAnswers")
		{
			RA = atoi(argv[i]);
		}
		else if (string(azColName[i]) == "wrongAnswers")
		{
			WA = atoi(argv[i]);
		}
		else if (string(azColName[i]) == "averageTime")
		{
			AT = atoi(argv[i]);
		}
	}
	players.push_back(Player(name, NOG, RA, WA, AT));

	return 0;
}

int forHighScores(void *data, int argc, char **argv, char **azColName)
{
	string name;
	int RA;
	for (int i = 0; i < argc; i++)
	{
		if (string(azColName[i]) == "player_name")
		{
			name = argv[i];
		}
		else if (string(azColName[i]) == "rightAnswers")
		{
			RA = atoi(argv[i]);
		}

		
	}
	highScores.insert(std::pair<string, int>(name, RA));
	return 0;
}

int forQuestions(void *data, int argc, char **argv, char **azColName)
{
	Question q;

	for (int i = 0; i < argc; i++)
	{
		if (string(azColName[i]) == "question")
		{
			q.question = argv[i];
		}
		else if (string(azColName[i]) == "right_answer")
		{
			q.rightAnswer = argv[i];
		}
		else if (string(azColName[i]) == "answer1" || string(azColName[i]) == "answer2" || string(azColName[i]) == "answer3")
		{
			q.answers.push_back(argv[i]);
		}
	}
	questions.push_back(q);
	return 0;
}

int forPassword(void *data, int argc, char **argv, char **azColName)
{
	for (int i = 0; i < argc; i++)
	{
		if (string(azColName[i]) == "password")
		{
			pazword = argv[i];
		}
	}
	return 0;	
}