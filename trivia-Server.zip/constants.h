#pragma once 


#include <string>

//requests and responses codes
enum Codes
{
	LOGIN = 1,
	LOGOUT,
	SIGNUP,
	ROOM_REQUEST = 4,
	STATUS = 5,
	QUESTIONS = 6,
	END_GAME =  7,
	OK = 200,
	NOT_FOUND = 204,
	ERRoR = 255,
	ALREADY_EXIST = 100
};

namespace requests
{
	//structs:
	typedef struct LoginRequest
	{
		std::string username;
		std::string password;
	}LoginRequest;

	typedef struct SignupRequest
	{
		std::string username;
		std::string password;
		std::string email;
	}SignupRequest;

	typedef struct Request
	{
		unsigned int id;
		std::string data;
	}Request;

	typedef struct User
	{
		std::string _name;
		std::string _password;
		std::string _email;

		struct User setUser(std::string name, std::string password, std::string email)
		{
			struct User us;
			us._name = name;
			us._password = password;
			us._email = email; 
			return us;
		}
	}User;
}

namespace responses
{
	typedef struct LoginResponse
	{
		unsigned int status;
	}LoginResponse;

	typedef struct SignupResponse
	{
		unsigned int status;
	}SignupResponse;

	typedef struct RequestResult
	{
		unsigned int response;
		std::string data;
	}RequestResult;
}