#pragma once

#include "constants.h"
#include "LoginManager.h"

class LoginRequestHandler
{
public:
	LoginRequestHandler();
	~LoginRequestHandler();

	bool isRelevant(requests::Request req);
	responses::RequestResult handleRequest(requests::Request req);
	bool login(requests::LoginRequest req);
	//RequestsDeserializer reqDeserializer;
private:
	LoginManager _manager;
};

