#include "Room.h"

Room::Room(int QN, int PN, int TFQ, std::string name, std::string adminName):
	_questionsNumber(QN), _playersNumber(PN), _name(name)
{
	addPlayer(adminName);
	is_full = _players.size() == _playersNumber ? true : false;
}

Room::Room()
{

}


Room::~Room()
{

}

void Room::addPlayer(std::string name)
{
	_players.push_back(Player(name));
	is_full = _players.size() == _playersNumber ? true : false;
}

void Room::removePlayer(std::string name)
{
	for (auto it = _players.begin(); it != _players.end(); ++it)
	{
		if (it->name() == name.c_str())
		{
			_players.erase(it);
		}
	}
}

void Room::updatePlayersStats(Player p)
{
	
	for (auto player = this->_players.begin(); player != this->_players.end(); ++player)
	{
		if (p.name() == player->name())
		{
			player->averageTime += p.averageTime;
			player->numOfGames += p.numOfGames;
			player->rightAnswers += p.rightAnswers;
			player->wrongAnswers += p.wrongAnswers;
		}
	}
}

void Room::updateDatabase()
{
	Player p;
	for (auto it = _players.begin(); it != _players.end(); ++it)
	{
		try
		{
			p = _database.getStatus(it->name());
			p += *it;
			p.numOfGames += 1;
			_database.updateStatus(p);
		}
		catch (std::exception& e)
		{
			std::cout << "Exception occured at '" << __FUNCTION__ << "' " <<
				e.what();
		}
	}
	
}