#pragma once

#include <list>

#include "IDatabase.h"
#include "Player.h"

class Room
{
public:
	Room(int QN, int PN, int TFQ, std::string name, std::string adminName);
	Room();
	~Room();

	std::list<Player> _players;

	std::string _name;
	unsigned int _questionsNumber;
	unsigned int _playersNumber;
	unsigned int _timeForQuestion;
	
	bool is_full;

	void addPlayer(std::string name);
	void removePlayer(std::string name);
	void updatePlayersStats(Player p);
	void updateDatabase();

private:
	IDatabase _database;
};

