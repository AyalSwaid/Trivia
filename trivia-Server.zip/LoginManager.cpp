#include "LoginManager.h"



LoginManager::LoginManager()
{

}


LoginManager::~LoginManager()
{

}

responses::SignupResponse LoginManager::signup(requests::User user)
{
	_database.signup(user);
	return responses::SignupResponse();
}

bool LoginManager::isUserExist(requests::User user)
{
	return _database.is_exist(user);
}

bool LoginManager::login(requests::LoginRequest req)
{
	std::string password = _database.getPassword(req.username);

	return password == req.password.c_str();
}