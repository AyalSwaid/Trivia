#include "LoginRequestHandler.h"
#include "RequestsDeserializer.h"

LoginRequestHandler::LoginRequestHandler()
{

}


LoginRequestHandler::~LoginRequestHandler()
{

}

bool LoginRequestHandler::isRelevant(requests::Request req)
{
	// the program may fail here because reqID type have to be Codes.
	int reqID = req.id;
	//RequestsDeserializer reqD;
	requests::LoginRequest loginReq = RequestsDeserializer().deserializeLoginRequest(req.data);
	
	requests::User user;
	user._name = loginReq.username;

	bool userExist = _manager.isUserExist(user);
	switch (reqID)
	{
		case LOGOUT:
		case LOGIN:
			return userExist;

		case SIGNUP:
			return !userExist;
	}
}

responses::RequestResult LoginRequestHandler::handleRequest(requests::Request req)
{
	responses::RequestResult result;
	requests::SignupRequest signReq;
	requests::User user;

	switch (req.id)
	{
		case SIGNUP:
			signReq = RequestsDeserializer().deserializeSignupRequest(req.data);

			user = user.setUser(signReq.username, signReq.password, signReq.email);
			
			_manager.signup(user);

			result.response = OK;
			break;

		default:
			result.response = ERRoR;
	}

	return result;
}

bool LoginRequestHandler::login(requests::LoginRequest req)
{
	
	return _manager.login(req);
}