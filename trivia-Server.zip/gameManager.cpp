#include "gameManager.h"
#include "Question.h"
#include "RequestsDeserializer.h"

gameManager::gameManager()
{
}


gameManager::~gameManager()
{
}

responses::RequestResult gameManager::getQuestions(requests::Request req)
{
	/*
		get the questions from the database and return it in the rellevent format for the 
		protocol.

		input: requests::Request
		output: responses::RequestResult.
	*/
	int numberOfQuestions = RequestsDeserializer().GetNumberOfQuestions(req.data);

	std::vector<Question> qwsts = _myDatabase.getQuestions(numberOfQuestions);
	responses::RequestResult res;

	string resp;

	for (const auto q : qwsts)
	{
		resp += q.question + ":";
		resp += q.rightAnswer + "|";
		for (const auto qq : q.answers)
		{
			resp += qq + "|";
		}
		resp.pop_back();// delete the space.
		resp += ",";
	}
	resp.pop_back();// delete the ','.

	res.data = resp;
	res.response = OK;

	return res;
	
}