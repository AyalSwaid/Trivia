#include <map>

#include "menuRequestHandler.h"

#define NUMBER_OF_QUESTION 5

menuRequestHandler::menuRequestHandler()
{
}


menuRequestHandler::~menuRequestHandler()
{
}

responses::RequestResult menuRequestHandler::roomRequestHandler(requests::Request req)
{
	std::vector<string> vec = RequestsDeserializer().deserializeRoomRequest(req.data);
	responses::RequestResult res;
	
	if (!vec.size())
	{
		// get rooms list request
		res.data = getRoomsList();// 'roomname:playername1 playername2, roomname:playername1 playername2
		res.response = OK;
	}
	else if (vec.size() == 1)
	{
		// leave room request
		leaveRoom(vec[0]);
		res.response = OK;
	}
	else if (vec.size() == 2)
	{
		// join room request
		res.data = joinRoom(vec[0], vec[1]);
		res.response = OK;
	}
	else if (vec.size() == 5)
	{
		// create room request
		Room newRoom = RequestsDeserializer().createRoomRequest(vec);
		if (newRoom._questionsNumber > NUMBER_OF_QUESTION)
		{
			res.response = ERRoR;
		}
		else
		{
			createRoom(newRoom);
			res.response = OK;
		}
	}

	return res;
}

void menuRequestHandler::createRoom(Room rom)
{
	this->_rooms.push_back(rom);
}

std::string menuRequestHandler::getRoomsList()
{
	std::map<std::string, std::list<Player>> list_rooms;
	if (_rooms.empty())
	{
		return "";
	}
	for (const auto rm : _rooms)
	{
		if (!rm.is_full)
		{
			list_rooms.insert(std::pair<string, std::list<Player>>(rm._name, rm._players));
		}
	}
	
	if (list_rooms.empty())
	{
		return "";
	}
	std::string result = "";

	for (const auto el : list_rooms)
	{
		result += el.first + ":";
		for (auto plyer : el.second)
		{
			result += plyer.name() + " ";
		}
		result.pop_back();
		result += ",";
	}
	result.pop_back();

	return result;
}

std::string menuRequestHandler::joinRoom(std::string adminName, std::string playerName)
{// return the room details.
	for (auto rom = _rooms.begin(); rom != _rooms.end(); ++rom)
	{
		for (auto plyr : rom->_players)
		{
			if (plyr.name() == adminName)
			{
				rom->addPlayer(playerName);
				int TFQ = rom->_timeForQuestion;
				int NQ = rom->_questionsNumber;
				
				std::string details = std::to_string(NQ) + "," + std::to_string(TFQ) + ",";
				for (auto p : rom->_players)
				{
					details += p.name() + ",";
				}
				details.pop_back();
				
				return details;
			}
		}
		
	}
}

void menuRequestHandler::leaveRoom(std::string playerName)
{
	for (auto rom = _rooms.begin() ; rom != _rooms.end(); ++rom)
	{
		for (auto it = rom->_players.begin(); it != rom->_players.end(); ++it)
		{
			if (it->name() == playerName.c_str())
			{
				rom->_players.erase(it);
				return;
			}
		}
	}
}

responses::RequestResult menuRequestHandler::getStats(requests::Request req)
{
	std::vector<string> vec = RequestsDeserializer().deserializeRoomRequest(req.data);
	responses::RequestResult res;
	std::string stats;

	if (vec.size() == 0)
	{// high scores.
		std::map<string, int> stats_dict = yeah_database.getHighscores();
		for (const auto plyr : stats_dict)
		{
			stats += plyr.first + ':' + std::to_string(plyr.second) + ",";
		}
		stats.pop_back();// delete the last ','
	}
	else if (vec.size() == 1)
	{// my status
		Player p;
		p = yeah_database.getStatus(vec[0]);

		stats = std::to_string(p.numOfGames) + "," + std::to_string(p.rightAnswers) + "," + std::to_string(p.wrongAnswers) + "," + std::to_string(p.averageTime);
	}

	res.data = stats;
	res.response = OK;

	return res;
}

responses::RequestResult menuRequestHandler::updatePlayersStats(requests::Request req)
{
	std::pair<string, std::vector<int>> playersStats = RequestsDeserializer().deserializeStats(req.data);
	
	std::list<Player> plyers;
	responses::RequestResult res;

	

	for (auto it = _rooms.begin(); it != _rooms.end(); ++it)
	{
		for (auto player : it->_players)
		{
			if (playersStats.first == player.name())
			{
				it->updatePlayersStats(Player(playersStats.first, 1, playersStats.second[0], playersStats.second[1], 0));
				it->updateDatabase();
				res.response = OK;
				return res;
			}
		}
	}
}