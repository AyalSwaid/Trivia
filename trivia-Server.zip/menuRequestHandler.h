#pragma once

#include "Room.h"
#include "constants.h"
#include "RequestsDeserializer.h"
#include "IDatabase.h"

class menuRequestHandler
{
public:
	menuRequestHandler();
	~menuRequestHandler();

	responses::RequestResult roomRequestHandler(requests::Request req);

	responses::RequestResult getStats(requests::Request req);

	responses::RequestResult updatePlayersStats(requests::Request req);
	
private:
	void createRoom(Room rom);
	std::string getRoomsList();
	std::string joinRoom(std::string adminName, std::string playerName);
	void leaveRoom(std::string playerName);
	std::vector<Room> _rooms;
	
	IDatabase yeah_database;
};

