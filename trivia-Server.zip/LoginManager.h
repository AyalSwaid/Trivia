#pragma once
#include <string>

#include "constants.h"
#include "IDatabase.h"

class LoginManager
{
public:
	LoginManager();
	~LoginManager();

	responses::SignupResponse signup(requests::User user);
	bool isUserExist(requests::User user);
	bool login(requests::LoginRequest req);

private:
	IDatabase _database;
};
