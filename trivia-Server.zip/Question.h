#pragma once

#include <vector>

using std::string;

class Question
{
public:
	Question();
	~Question();

	string question;
	string rightAnswer;

	std::vector<string> answers;
};

