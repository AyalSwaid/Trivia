#include <iterator>

#include "Communicator.h"
#include "RequestsDeserializer.h"
#include "LoginRequestHandler.h"
#include "ResponseSerializer.h"
#include "gameManager.h"


Communicator::Communicator()
{
	// this server use TCP. that why SOCK_STREAM & IPPROTO_TCP
	// if the server use UDP we will use: SOCK_DGRAM & IPPROTO_UDP
	_serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (_serverSocket == INVALID_SOCKET)
		throw std::exception(__FUNCTION__ " - socket");
}


Communicator::~Communicator()
{
	try
	{
		// the only use of the destructor should be for freeing 
		// resources that was allocated in the constructor
		closesocket(_serverSocket);
	}
	catch (...) {}
}

void Communicator::serve()
{
	/*
		open a listining socket, and accept clients and handle their requests.
	*/
	bindAndListen(PORT);
	
	std::thread t1(&Communicator::handleRequests, this);
	t1.detach();

	while (true)
	{
		// the main thread is only accepting clients 
		// and add then to the list of handlers
		//std::cout << "Waiting for client connection request" << std::endl;
		accept();
	}
}

void Communicator::bindAndListen(int port)
{
	/*
		open a listining socket and wiat for client.
	*/
	struct sockaddr_in sa = { 0 };

	sa.sin_port = htons(port); // port that server will listen for
	sa.sin_family = AF_INET;   // must be AF_INET
	sa.sin_addr.s_addr = INADDR_ANY;    // when there are few ip's for the machine. We will use always "INADDR_ANY"

										// again stepping out to the global namespace
										// Connects between the socket and the configuration (port and etc..)
	if (bind(_serverSocket, (struct sockaddr*)&sa, sizeof(sa)) == SOCKET_ERROR)
		throw std::exception(__FUNCTION__ " - bind");

	// Start listening for incoming requests of clients
	if (listen(_serverSocket, SOMAXCONN) == SOCKET_ERROR)
		throw std::exception(__FUNCTION__ " - listen");
	std::cout << "Listening on port " << port << std::endl;

}

void Communicator::accept()
{
	/*
		accept client's socket and open conversasion.
	*/
	// notice that we step out to the global namespace
	// for the resolution of the function accept

	// this accepts the client and create a specific socket from server to this client
	SOCKET client_socket = ::accept(_serverSocket, NULL, NULL);

	if (client_socket == INVALID_SOCKET)
		throw std::exception(__FUNCTION__);

	std::cout << "Client accepted." << std::endl;

	// the function that handle the conversation with the client
	std::thread t2(&Communicator::clientHandler, this, client_socket);
	//clientHandler(client_socket);
	t2.detach();
} 

void Communicator::clientHandler(SOCKET client_socket)
{
	/*
		gets the request from the client, deserialize it and add it to the requests queue.
	*/
	std::string msg_data;
	char request[500];

	recv(client_socket, request, 500, 0);

	std::string string_request(request);


	// finding the request code(what is the request)
	Codes code = static_cast<Codes>(std::stoull(string_request.substr(0, 8), 0, 2));
	
	// finding the length of the data.
	int length = std::stoull(string_request.substr(8, 32), 0, 2);

	// get the data.
	if(length)
		msg_data = string_request.substr(40, 40 + (length * 8));

	// deserialize the data(put the buffer in structs)				
	requests::Request req;
	req.id = code;
	req.data = msg_data;
	cout << "request data: " << req.data << endl;
	_clients.push_back(client(client_socket, req));
}

void Communicator::handleRequests()
{
	/*
		handle the request of the client and get the rellevent response from the requests 
		managers.
	*/
	while (true)
	{
		try
		{
			std::string response = "";
			responses::RequestResult result;
			
			while (_clients.empty())
			{

			}
			client request = _clients.front();
			_clients.pop_front();

			int code = request.second.id;

			LoginRequestHandler handler = LoginRequestHandler();
			requests::LoginRequest logoutReq;
			// dealing with the request
			switch (code)
			{
			case LOGIN:
			case SIGNUP:
				// check if the request is relevant.
				if (handler.isRelevant(request.second))
				{
					// add the user 
					requests::LoginRequest loginReq;
					try
					{
						switch (code)
						{
						case LOGIN:
							loginReq = RequestsDeserializer().deserializeLoginRequest(request.second.data);
							if (std::find(_onlineUsers.begin(), _onlineUsers.end(), loginReq.username) == _onlineUsers.end())
							{// if username not in _onlineUsers.
								
								if (handler.login(loginReq))
								{
									this->_onlineUsers.push_back(loginReq.username);
									result.response = OK;
								}
								else
								{// wrong password
									result.response = ERRoR;
								}
							}
							else
							{
								result.response = ALREADY_EXIST;
							}
							break;

						case SIGNUP:
							// handle the request.
							result = handler.handleRequest(request.second);
							break;
						}
					}
					catch (...)
					{
						result.response = ERRoR;
					}
				}
				else
				{
					switch (code)
					{
					case LOGIN:
						result.response = NOT_FOUND;
						break;

					case SIGNUP:
						result.response = ALREADY_EXIST;
						break;
					}
				}

				// Serialize and put the result in the response as a string
				response = ResponseSerializer().serializeResponse(result);
				break;

			case LOGOUT:
				logoutReq = RequestsDeserializer().deserializeLoginRequest(request.second.data);

				deleteUser(logoutReq.username);
				result.response = OK;

				break;

			case ROOM_REQUEST:
				result = _menuManager.roomRequestHandler(request.second);
				break;

			case STATUS:
				result = _menuManager.getStats(request.second);
				break;

			case QUESTIONS:
				result = gameManager().getQuestions(request.second);
				break;

			case END_GAME:
				result = _menuManager.updatePlayersStats(request.second);
				break;
			}

			// Serialize and put the result in the response as a string
			response = ResponseSerializer().serializeResponse(result);

			std::cout << "Response: " << response << endl;
			// send a response to the client.
			resp(request, response);

			std::cout << __FUNCTION__ << "  ONLINE USERS: ";
			for (const auto us : _onlineUsers)
			{
				std::cout << us << endl;
			}
		}
		catch (const std::exception& e)
		{
			std::cout << __FUNCTION__ << "\t" << e.what();
		}
	}
}

void Communicator::resp(client cli, std::string response)
{
	/*
		send response socket to the client.
		input: cli: std::Pair<SOCKET, requests::Request>
		output: none.
	*/
	send(cli.first, response.c_str(), response.size(), 0);// last parameter: flag. for us will be 0.
	closesocket(cli.first);
}

void Communicator::deleteUser(std::string name)
{
	/*
		delete user from the onlineUsers list, this function is called on the logout event.
	*/
	for (auto it = _onlineUsers.begin(); it != _onlineUsers.end(); ++it)
	{
		if (*it == name.c_str())
		{
			this->_onlineUsers.erase(it);
		}
		break;
	}

}