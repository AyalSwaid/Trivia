#pragma once

#include <string>
#include <vector>
#include <iostream>
#include <map>

#include "sqlite3.h"

#include "constants.h"
#include "Player.h"
#include "Question.h"

using std::string;
using std::cout;
using std::endl;



class IDatabase
{
public:
	IDatabase();
	~IDatabase();

	bool open();
	void close();

	// user 
	bool is_exist(requests::User user);
	bool signup(requests::User user);
	std::string getPassword(std::string username);

	// player and status
	Player getStatus(std::string name);
	void updateStatus(Player p);
	std::map<std::string, int> getHighscores();

	// questions
	std::vector<Question> getQuestions(int n);

private:

	// for new users
	void addStatusRow(std::string name);
};

