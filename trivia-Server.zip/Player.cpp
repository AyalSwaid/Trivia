#include "Player.h"

Player::Player(std::string nname, int NOG, int RA, int WA, int AT):
	_name(nname), numOfGames(NOG), rightAnswers(RA), wrongAnswers(WA),
	averageTime(AT)
{

}

Player::Player(std::string nname):
	Player(nname, 0, 0, 0, 0)
{

}

Player::Player()
{
}


Player::~Player()
{
}


std::string Player::name()
{
	return this->_name;
}

Player& Player::operator+=(const Player& other)
{
	this->averageTime += other.averageTime;
	this->rightAnswers += other.rightAnswers;
	this->wrongAnswers += other.wrongAnswers;
	
	return *this;
}