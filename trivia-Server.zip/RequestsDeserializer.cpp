#include "RequestsDeserializer.h"
#include <iostream>

RequestsDeserializer::RequestsDeserializer()
{
}


RequestsDeserializer::~RequestsDeserializer()
{
}

// Buffer data: name,password.
requests::LoginRequest RequestsDeserializer::deserializeLoginRequest(std::string Buffer)
{
	std::string text = toText(Buffer);
	std::string element;// element of the text after splitting.

	std::stringstream test(text);

	std::vector<std::string> data;

	while (std::getline(test, element, ','))
	{
		data.push_back(element);
	}

	requests::LoginRequest request;
	request.username = data[0];
	if (data.size() > 1)//because if it was a logout request then there will not be
	{// data[1]
		request.password = data[1];
	}
	
	return request;
}

requests::SignupRequest RequestsDeserializer::deserializeSignupRequest(std::string Buffer)
{
	std::string text = toText(Buffer);
	std::string element;// element of the text after splitting.

	std::stringstream test(text);

	std::vector<std::string> data;

	while (std::getline(test, element, ','))
	{
		data.push_back(element);
	}

	requests::SignupRequest req;
	req.username = data[0];
	req.password = data[1];
	req.email = data[2];

	return req;
}

std::vector<std::string> RequestsDeserializer::deserializeRoomRequest(std::string Buffer)
{
	std::vector<std::string> data;
	if (!Buffer.size())
	{
		return data;
	}

	std::string text = toText(Buffer);
	std::string element;// element of the text after splitting.

	std::stringstream test(text);

	while (std::getline(test, element, ','))
	{
		data.push_back(element);
	}

	return data;
}

Room RequestsDeserializer::createRoomRequest(std::vector<string> vec)
{
	return Room(atoi(vec[3].c_str()), atoi(vec[2].c_str()), atoi(vec[4].c_str()), vec[0], vec[1]);
}

std::pair<string, std::vector<int>> RequestsDeserializer::deserializeStats(std::string Buffer)
{
	std::pair<string, std::vector<int>> playersStats;

	std::string text = toText(Buffer);
	
	std::vector<string> player = split(text, ',');
	std::string playerName = player[0];
	std::vector<int> stats;



	for (int i = 1; i < player.size(); i++)
	{
		stats.push_back(atoi(player[i].c_str()));
	}

	return std::pair<string, std::vector<int>>(playerName, stats);
}

int RequestsDeserializer::GetNumberOfQuestions(std::string buffer)
{
	std::string txt = toText(buffer);

	return atoi(txt.c_str());
}

std::string RequestsDeserializer::toText(std::string data)
{
	std::string result = "";

	for (int i = 0; i < data.size(); i += 8)
	{
		result += binToChar(data.substr(i, i + 8).c_str());
	}
	return result;
}

char RequestsDeserializer::binToChar(const char* str)
{
	char parsed = 0;
	for (int i = 0; i < 8; i++) {
		if (str[i] == '1') {
			parsed |= 1 << (7 - i);
		}
	}
	return parsed;
}

std::vector<string> RequestsDeserializer::split(string str, char c)
{
	std::vector<string> newStr;
	string tmp;

	for (const auto chr : str)
	{
		if (chr != c)
		{
			tmp += chr;
		}
		else
		{
			newStr.push_back(tmp);
			tmp.clear();
		}
	}
	return newStr;
}