#pragma once

#include "constants.h"
#include "IDatabase.h"

class gameManager
{
public:
	gameManager();
	~gameManager();

	responses::RequestResult getQuestions(requests::Request req);

private:
	IDatabase _myDatabase;
};

