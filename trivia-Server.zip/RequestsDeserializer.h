#pragma once

#include <sstream>
#include <vector>
#include <string>

#include "constants.h"
#include "Room.h"

/*
	Deserialize the requests(buffer->struct).
*/
class RequestsDeserializer
{
public:
	RequestsDeserializer();
	~RequestsDeserializer();

	requests::LoginRequest deserializeLoginRequest(std::string Buffer);
	requests::SignupRequest deserializeSignupRequest(std::string Buffer);

	std::vector<std::string> deserializeRoomRequest(std::string Buffer);
	Room createRoomRequest(std::vector<string> vec);

	int GetNumberOfQuestions(std::string buffer);

	std::pair<string, std::vector<int>> deserializeStats(std::string Buffer);

private:
	std::string toText(std::string data);
	char binToChar(const char* str);
	std::vector<string> split(string str, char c);
};

