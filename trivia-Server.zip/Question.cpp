#include "Question.h"



Question::Question()
{
}


Question::~Question()
{
}
