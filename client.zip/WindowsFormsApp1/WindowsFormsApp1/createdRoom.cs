﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    public partial class createdRoom : Form
    {
        Form1 _form1 = new Form1();
        
        string _timeForAnswer;
        string _numOfQuestions;
        public createdRoom(ref Form1 f, string TimeforAns, string numOfQuestions, List<string> playersInRoom)
        {
            _form1 = f;
            this.listBox1 = new System.Windows.Forms.ListBox();
            if (this.listBox1 != null)
            {
                this.listBox1.Items.Clear();
            }

            foreach (string pl in playersInRoom)
            {
                this.listBox1.Items.Add(pl);
            }

            _timeForAnswer = TimeforAns;
            _numOfQuestions = numOfQuestions;

            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)//close room button
        {
            string playerName = constants.player_name;

            string msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength(playerName.Length) + _form1.myClientServer.serializeString(playerName);//code of close room
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);

            if (msgCode == constants.OK)
            {
                this.Close();
                _form1.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)//start game button
        {
            /*
            string msgToSend = _form1.myClientServer.serializeCode(6) + _form1.myClientServer.serializeLength(this._numOfQuestions.Length) + _form1.myClientServer.serializeString(this._numOfQuestions);//code of start game
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            if(msgCode == constants.OK)
            {
                string response = _form1.myClientServer.binToStr(msgFromServer.Substring(40));

                Dictionary<string, List<string>> questions_list = _form1.splitResp.splitQuestions(response);
                // dict format: <string question, list<string> { answer1, answer2, answer3, answer4 }>
                // the right answer is the first one.

                // TODO: play the game :)
                Form1 f = _form1 as Form1;
                QuestionForm questionForm = new QuestionForm(ref f, questions_list, msgFromServer, _timeForAnswer, _numOfQuestions);

                questionForm.Show();
                this.Hide();

            }
            */
            string roomName = label2.Text + ",";
            string currentParticipants = listBox1.Text + ",";
            string playerName = constants.player_name;

            string msgToSend = _form1.myClientServer.serializeCode(6) + _form1.myClientServer.serializeLength(this._numOfQuestions.Length) + _form1.myClientServer.serializeString(this._numOfQuestions);//code of start game
            //string msgToSend = _form1.myClientServer.serializeCode(6) + _form1.myClientServer.serializeLength( playerName  .Length) + _form1.myClientServer.serializeString( playerName  );
            //string msgToSend = _form1.myClientServer.serializeCode(6) + _form1.myClientServer.serializeLength(playerName.Length) + _form1.myClientServer.serializeString(playerName);
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            if (msgCode == constants.OK)
            {

                string response = _form1.myClientServer.binToStr(msgFromServer.Substring(40));

                Dictionary<string, List<string>> questions_list = _form1.splitResp.splitQuestions(response);


                Form1 f = _form1 as Form1;
                QuestionForm questionForm = new QuestionForm(ref f, response, questions_list, _timeForAnswer, _numOfQuestions);
                //Thread timerThread = new Thread(questionForm.timerFunction);
                //timerThread.Start();
                questionForm.Show();

                this.Hide();
                //questionForm.getFirstQuestion();

                // dict format: <string question, list<string> { answer1, answer2, answer3, answer4 }>
                // the right answer is the first one.

                // TODO: play the game :)

            }
        }

        

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void createdRoom_Load(object sender, EventArgs e)
        {

        }
    }
}
