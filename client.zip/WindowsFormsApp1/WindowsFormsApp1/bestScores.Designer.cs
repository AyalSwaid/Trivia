﻿namespace WindowsFormsApp1
{
    partial class bestScores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.P1 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.P3 = new System.Windows.Forms.Label();
            this.P5 = new System.Windows.Forms.Label();
            this.P4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(137, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(200, 39);
            this.label1.TabIndex = 6;
            this.label1.Text = "Best Scores";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(491, 47);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // P1
            // 
            this.P1.AutoSize = true;
            this.P1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.P1.Location = new System.Drawing.Point(206, 106);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(78, 24);
            this.P1.TabIndex = 8;
            this.P1.Text = "player1";
            // 
            // P2
            // 
            this.P2.AutoSize = true;
            this.P2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.P2.Location = new System.Drawing.Point(206, 151);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(78, 24);
            this.P2.TabIndex = 9;
            this.P2.Text = "player2";
            // 
            // P3
            // 
            this.P3.AutoSize = true;
            this.P3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.P3.Location = new System.Drawing.Point(206, 191);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(78, 24);
            this.P3.TabIndex = 10;
            this.P3.Text = "player3";
            // 
            // P5
            // 
            this.P5.AutoSize = true;
            this.P5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.P5.Location = new System.Drawing.Point(206, 280);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(78, 24);
            this.P5.TabIndex = 11;
            this.P5.Text = "player5";
            // 
            // P4
            // 
            this.P4.AutoSize = true;
            this.P4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.P4.Location = new System.Drawing.Point(206, 237);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(78, 24);
            this.P4.TabIndex = 12;
            this.P4.Text = "player4";
            // 
            // bestScores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 358);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.P5);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "bestScores";
            this.Text = "bestScores";
            this.Load += new System.EventHandler(this.bestScores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label P1;
        private System.Windows.Forms.Label P2;
        private System.Windows.Forms.Label P3;
        private System.Windows.Forms.Label P5;
        private System.Windows.Forms.Label P4;
    }
}