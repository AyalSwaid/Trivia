﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class joinRoom : Form
    {
        Form1 _form1 = new Form1();
        public joinRoom(ref Form1 f)
        {
            _form1 = f;
            InitializeComponent();
        }

        public void addValues(List<string> _roomsNames)
        {
            comboBox1.Items.Clear();
            if(_roomsNames == null)
            {
                no_rooms.Show();
                button2.Enabled = false;
            }
            else
            {
                foreach(string n in _roomsNames)
                {
                    comboBox1.Items.Add(n);
                }
                no_rooms.Hide();
                button2.Enabled = true;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)//back
        {
            this.Close();
            _form1.Show();
        }

        private void button1_Click(object sender, EventArgs e)//refresh button
        {
            
            string msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength(0);
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);
            Dictionary<string, List<string>> rooms = null;
            if (msgCode == constants.OK)
            {
                
                // rooms format: <string roomName, list<string> players {player1, player2,...}>
                // *note* rooms is also stored in constants static class
                if(length != 0)
                {
                    string response = _form1.myClientServer.binToStr(msgFromServer.Substring(40));

                    rooms = _form1.splitResp.splitRooms(response);
                    addValues(rooms.Keys.ToList());
                }
                else
                {
                    addValues(null);
                }
                // TODO: show the rooms
            }
        }

        private void button2_Click(object sender, EventArgs e)//join button
        {
            Form1 f = _form1 as Form1;



            string playerName = constants.player_name;
            string playerInTheRoom = players_list.Items[0].ToString();// (name) should be the first one.
            

            string msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength((playerName + "," + playerInTheRoom).Length) + _form1.myClientServer.serializeString(playerInTheRoom + "," + playerName);
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            if (msgCode == constants.OK)
            {
                // success :)
                string response = _form1.myClientServer.binToStr(msgFromServer.Substring(40));
                Dictionary<List<string>, List<string>> RoomDetails = _form1.splitResp.splitRoomDetails(response);
                createdRoom createdRoomForm = new createdRoom(ref f, RoomDetails.Keys.ToList<List<string>>()[0][0], RoomDetails.Keys.ToList<List<string>>()[0][1], RoomDetails.Values.SelectMany(c => c).ToList() );

                this.Hide();
                createdRoomForm.Show();
            }

        }

        private void joinRoom_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            players_list.Items.Clear();
            List<string> playersNames = constants._rooms[comboBox1.Text];

            foreach (string n in playersNames)
            {
                players_list.Items.Add(n);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
