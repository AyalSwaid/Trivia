﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class signUp : Form
    {
        Form1 _form1 = new Form1();
        public signUp(ref Form1 f)
        {
            _form1 = f;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)//user name
        {

        }

        private void label2_Click(object sender, EventArgs e)//password
        {

        }

        private void label3_Click(object sender, EventArgs e)//email
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)//user name text
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//password text
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)//email text
        {

        }

        private void button1_Click(object sender, EventArgs e)//ok bottun
        {
            //TcpClient client = new TcpClient();
            string msgToSend = _form1.myClientServer.serializeCode(3) + _form1.myClientServer.serializeLength((textBox1.Text + "," + textBox2.Text + "," + textBox3.Text).Length) + _form1.myClientServer.serializeString(textBox1.Text + "," + textBox2.Text + "," + textBox3.Text);
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);
            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);

            if (msgCode == constants.OK)
            {
                this.Close();
                _form1.Show();
            }
            else if(msgCode == constants.ALREADY_EXIST)
            {
                this.Text = "username is already taken.";
            }
        }

        private void button2_Click(object sender, EventArgs e)//back
        {
            this.Close();
            _form1.Show();
        }
    }
}
