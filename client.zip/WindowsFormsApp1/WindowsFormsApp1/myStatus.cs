﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class myStatus : Form
    {
        Form1 _form1 = new Form1();
        public myStatus(ref Form1 f, int nog, int ra, int wa, int at)
        {
            _form1 = f;
            InitializeComponent();
            this.RA.Text = ra.ToString();
            this.NOF.Text = nog.ToString();
            this.WA.Text = wa.ToString();
            this.AT.Text = at.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
            _form1.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void myStatus_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void NOF_Click(object sender, EventArgs e)
        {

        }
    }
}
