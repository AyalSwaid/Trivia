﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class createRoom : Form
    {
        Form1 _form1 = new Form1();
        public createRoom(ref Form1 f)
        {
            _form1 = f;
            InitializeComponent();
        }

    

        private void button2_Click(object sender, EventArgs e)//
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)//
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)//
        {

        }

        private void createRoom_Load(object sender, EventArgs e)//
        {

        }

        private void button8_Click(object sender, EventArgs e)//back button
        {
            this.Close();
            _form1.Show();
        }

        private void button3_Click(object sender, EventArgs e)//room name button
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)//room name text
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)//num of players text
        {

        }

        private void button7_Click(object sender, EventArgs e)//send button
        {
            string roomName = textBox5.Text;// + ",";
            string playersNum = textBox6.Text;// + ",";
            string questionsNum = textBox7.Text;// + ",";
            string timeForQuestion = textBox8.Text ;

            string playerName = constants.player_name;// + ",";

            string msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength((roomName + "," + playerName + "," + playersNum + "," + questionsNum + "," + timeForQuestion).Length) + _form1.myClientServer.serializeString(roomName + "," + playerName + "," + playersNum + "," + questionsNum + "," + timeForQuestion);
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);

            if (msgCode == constants.OK)
            {
                List<string> players = new List<string>();
                players.Add(playerName);

                Form1 f = _form1 as Form1;
                createdRoom createdRoom = new createdRoom(ref f, timeForQuestion, questionsNum, players);
                //createdRoom.NameOfUser.Text = NameOfUser.Text;

                createdRoom.Show();

                this.Close();
            }
            else if(msgCode == constants.ERROR)
            {
                label6.ForeColor = Color.Red;
            }

        }

        private void button6_Click(object sender, EventArgs e)//time for question button
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
