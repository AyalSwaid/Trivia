﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class bestScores : Form
    {
        Form1 _form1 = new Form1();
        public bestScores(ref Form1 f, List<Tuple<string, string>> scores)
        {
            _form1 = f;
            InitializeComponent();

            Tuple<string, string> nullTuple = new Tuple<string, string>("", "");

            while (scores.Count != 5)
            {
                scores.Add(nullTuple);
            }

            P1.Text = scores[0].Item1 + "-" + scores[0].Item2;
            P2.Text = scores[1].Item1 + "-" + scores[1].Item2; 
            P3.Text = scores[2].Item1 + "-" + scores[2].Item2;
            P4.Text = scores[3].Item1 + "-" + scores[3].Item2;
            P5.Text = scores[4].Item1 + "-" + scores[4].Item2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
            _form1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void bestScores_Load(object sender, EventArgs e)
        {

        }
    }
}
