﻿/*
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class QuestionForm : Form
    {
        Form1 _form1 = new Form1();
        string _msgFromServer;
        string _timeToAnswer;
        string _numOfQuestions;
        int _currentQuestion = 1;
        int _score = 0;
        public QuestionForm(ref Form1 f, Dictionary<string, List<string>> questions, string msgFromServer, string timeToAns, string numOfQuestion)
        {
            _form1 = f;
            _msgFromServer = msgFromServer;
            _timeToAnswer = timeToAns;
            _numOfQuestions = numOfQuestion;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//exit button
        {
            string msgToSend = "code??";//code of leave game
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);
            this.Close();
            _form1.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
        private void getFirstQuestion()
        {
            label4.Text = _timeToAnswer;

            label2.Text = "Question #" + _currentQuestion.ToString();

            // נעשה החיתוך כאן לפי איך שהשרת שולח את השאלה והתשובות
            label3.Text = _msgFromServer.Substring(0,3);
            button2.Text = _msgFromServer.Substring(0, 3);
            button3.Text = _msgFromServer.Substring(0, 3);
            button4.Text = _msgFromServer.Substring(0, 3);
            button5.Text = _msgFromServer.Substring(0, 3);
        }

        private void getNextQuestion()
        {
            button2.BackColor = Color.SteelBlue;
            button3.BackColor = Color.SteelBlue;
            button4.BackColor = Color.SteelBlue;
            button5.BackColor = Color.SteelBlue;

            
            _msgFromServer = _form1.myClientServer.sendToServer("code??");//code of get next question
            
            label4.Text = _timeToAnswer;

            label2.Text = "Question #" + _currentQuestion.ToString();

            // נעשה החיתוך כאן לפי איך שהשרת שולח את השאלה והתשובות
            label3.Text = _msgFromServer.Substring(0, 3);
            button2.Text = _msgFromServer.Substring(0, 3);
            button3.Text = _msgFromServer.Substring(0, 3);
            button4.Text = _msgFromServer.Substring(0, 3);
            button5.Text = _msgFromServer.Substring(0, 3);

            _currentQuestion++;
        }

        private void QuestionForm_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)//time left label
        {

        }

        private void label2_Click(object sender, EventArgs e)//qustion# label
        {

        }

        private void label3_Click(object sender, EventArgs e)//the question label
        {

        }

        private void button2_Click(object sender, EventArgs e)//ans1 button
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using System.Diagnostics;
using System.Threading;
using System.Globalization;

namespace WindowsFormsApp1
{
    public partial class QuestionForm : Form
    {
        Form1 _form1 = new Form1();
        string _response;
        Dictionary<string, List<string>> _msgFromServer;

        string _timeToAnswer = "-1";
        string _timeForQuestion;

        string _numOfQuestions;
        int _currentQuestion = 1;
        int _score = 0;
        string RightAnswer;
        Random rand = new Random();
        Stopwatch stopwatch = new Stopwatch();
        int c=0;




        public QuestionForm(ref Form1 f, string response, Dictionary<string, List<string>> msgFromServer, string timeToAns, string numOfQuestion)
        {
            

            _form1 = f;
            _response = response;
            _msgFromServer = msgFromServer;
            _timeToAnswer = timeToAns;
            _timeForQuestion = timeToAns;
            _numOfQuestions = numOfQuestion;
            // TODO: set room name.
            InitializeComponent();
        }
        

        private void button1_Click(object sender, EventArgs e)//exit button
        {
            string msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength(constants.player_name.Length) + _form1.myClientServer.serializeString(constants.player_name);//code of close room

            
            string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);
            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            if (msgCode == constants.OK)
            {
                this.Close();
                _form1.Show();
            }
        }

        

        private void label1_Click(object sender, EventArgs e)//room name
        {

        }

        private void QuestionForm_Load(object sender, EventArgs e)
        {
            getFirstQuestion();
            //Thread timerThread = new Thread(this.timerFunction);
            //timerThread.Start();
        }

        private void getFirstQuestion()
        {
            stopwatch.Start();

            button2.BackColor = Color.SteelBlue;
            button3.BackColor = Color.SteelBlue;
            button4.BackColor = Color.SteelBlue;
            button5.BackColor = Color.SteelBlue;

            //label4.Text = _timeToAnswer;

            label2.Text = "Question #" + _currentQuestion.ToString();



            label3.Text = _msgFromServer.ElementAt(this.rand.Next(0, _msgFromServer.Count)).Key;
            
            this.RightAnswer = _msgFromServer[label3.Text][0];
            _msgFromServer[label3.Text] = shuffleAnswers(_msgFromServer[label3.Text]);
            

            button2.Text = _msgFromServer[label3.Text][0];
            button3.Text = _msgFromServer[label3.Text][1];
            button4.Text = _msgFromServer[label3.Text][2];
            button5.Text = _msgFromServer[label3.Text][3];

            _msgFromServer.Remove(label3.Text);
        }



        private void getNextQuestion()
        {
            Thread.Sleep(200);
            
            if ((_currentQuestion) == Int32.Parse(_numOfQuestions))
            {
                stopwatch.Stop();
                string messageToShow = "your score is: " + _score ;
                MessageBox.Show(messageToShow);
                _timeToAnswer = "-1";

                string msg = constants.player_name + "," + _score.ToString() + "," + (Convert.ToInt32(_numOfQuestions) - _score).ToString() + "," + "0";
                string msgToSend = _form1.myClientServer.serializeCode(7) + _form1.myClientServer.serializeLength(msg.Length) + _form1.myClientServer.serializeString(msg);//code of start game
                string msgFromServer = _form1.myClientServer.sendToServer(msgToSend);

                int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
                   
                if(msgCode == constants.OK)
                {
                    msgToSend = _form1.myClientServer.serializeCode(4) + _form1.myClientServer.serializeLength(constants.player_name.Length) + _form1.myClientServer.serializeString(constants.player_name);//code of close room


                    msgFromServer = _form1.myClientServer.sendToServer(msgToSend);
                    msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
                    if (msgCode == constants.OK)
                    {
                        this.Close();
                        _form1.Show();
                    }
                }
            }
            else
            {
                button2.BackColor = Color.SteelBlue;
                button3.BackColor = Color.SteelBlue;
                button4.BackColor = Color.SteelBlue;
                button5.BackColor = Color.SteelBlue;
                //stopwatch.Stop();
                //stopwatch.Restart() ;
                _currentQuestion++;
                

                //label4.Text = _timeToAnswer;

                label3.Text = _msgFromServer.ElementAt(this.rand.Next(0, _msgFromServer.Count)).Key;

                

                label2.Text = "Question #" + _currentQuestion.ToString();


                label3.Text = _msgFromServer.ElementAt(this.rand.Next(0, _msgFromServer.Count)).Key;

                this.RightAnswer = _msgFromServer[label3.Text][0];
                _msgFromServer[label3.Text] = shuffleAnswers(_msgFromServer[label3.Text]);

                

                button2.Text = _msgFromServer[label3.Text][0];
                button3.Text = _msgFromServer[label3.Text][1];
                button4.Text = _msgFromServer[label3.Text][2];
                button5.Text = _msgFromServer[label3.Text][3];


                
                _msgFromServer.Remove(label3.Text);
            }


            

        }

        private List<E> shuffleAnswers<E>(List<E> inputList)
        {
            List<E> randomList = new List<E>();

            Random r = new Random();
            int randomIndex = 0;
            while (inputList.Count > 0)
            {
                randomIndex = r.Next(0, inputList.Count); //Choose a random object in the list
                randomList.Add(inputList[randomIndex]); //add it to the new, random list
                inputList.RemoveAt(randomIndex); //remove to avoid duplicates
            }

            return randomList; //return the new random list
        }

        

        private void label4_Click(object sender, EventArgs e)//time left label
        {
            
        }

        private void label2_Click(object sender, EventArgs e)//qustion# label
        {

        }

        private void label3_Click(object sender, EventArgs e)//the question label
        {

        }

        private void button2_Click(object sender, EventArgs e)//ans1 button
        {
            

            if (button2.Text == RightAnswer)
            {
                this.button2.BackColor = Color.LightGreen;
                _score++;

            }
            else
            {
                this.button2.BackColor = Color.Red;
            }
            /*
            while (stopwatch.Elapsed.TotalSeconds != Int32.Parse(_timeToAnswer))
            {
                c++;
            }
            */
            getNextQuestion();
           

        }

        private void button3_Click(object sender, EventArgs e)//ans2 button
        {
            label4.Text = RightAnswer;
            if (button3.Text == RightAnswer)
            {
                button3.BackColor = Color.LightGreen;
                _score++;

            }
            else
            {
                button3.BackColor = Color.Red;
                
            }
            
            /*
            while (stopwatch.Elapsed.TotalSeconds != Int32.Parse(_timeToAnswer))
            {
                c++;
            }
            */
            getNextQuestion();
        }

        

        private void timerFunction()
        {// thread function that called from QuestionForm_Load function.
            Thread.CurrentThread.CurrentUICulture = new CultureInfo("en-us");
            while (true)
            {
                while(Convert.ToInt32(_timeToAnswer) == -1)
                { }


                this.label4.Text = _timeToAnswer;

                

                Thread.Sleep(1000);
                _timeToAnswer = (Convert.ToInt32(_timeToAnswer)-1).ToString();
                if(Convert.ToInt32(_timeToAnswer) == 0)
                {
                    //getNextQuestion();
                    _timeToAnswer = _timeForQuestion;
                }
            }
            
        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)// ans 3
        {
            if (button4.Text == RightAnswer)
            {
                button4.BackColor = Color.LightGreen;
                _score++;

            }
            else
            {
                button4.BackColor = Color.Red;
            }
            /*
            while (stopwatch.Elapsed.TotalSeconds != Int32.Parse(_timeToAnswer))
            {
                c++;
            }
            */
            getNextQuestion();
        }

        private void button5_Click_1(object sender, EventArgs e)// ans 4
        {
            if (button5.Text == RightAnswer)
            {

                //button5.BackColor = Color.LightGreen;
                button5.BackColor = Color.LightGreen;
                _score++;

            }
            else
            {
                button5.BackColor = Color.Red;
            }
            /*
            while (stopwatch.Elapsed.TotalSeconds != Int32.Parse(_timeToAnswer))
            {
                c++;
            }
            */
            
            getNextQuestion();
        }
    }
    
}
