﻿using System;
using System.Net.Sockets;

namespace WindowsFormsApp1
{
    internal class client
    {
        internal static NetworkStream GetStream()
        {
            throw new NotImplementedException();
            
        }
    }
}