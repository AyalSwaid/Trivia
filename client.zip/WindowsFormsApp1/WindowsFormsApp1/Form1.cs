﻿using SimpleTCP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace WindowsFormsApp1
{

    static class constants
    {
        public const int OK = 200;
        public const int NOT_FOUND = 204;
        public const int ALREADY_LOGGED_IN = 100;
        public const int ALREADY_EXIST = 100;
        public const int ERROR = 255;

        public static List<int> status = new List<int>();
        public static Dictionary<string, List<string>> _rooms = new Dictionary<string, List<string>>();
        public static string player_name = null;
        public static Dictionary<List<string>, List<string>> _RoomDetails = new Dictionary<List<string>, List<string>>();

    }
    public partial class Form1 : Form
    {
        public clientServer myClientServer = new clientServer();
        public responsesSplitting splitResp = new responsesSplitting();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }

        private void label1_Click(object sender, EventArgs e)//username
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


        private void button1_Click(object sender, EventArgs e)
        {
            /*
                sign in button event handler.
                it will get the user's details and send them as a query to the server. 
            */
            string username = textBox1.Text;
            string password = textBox2.Text;

            string msgToSend = myClientServer.serializeCode(1) + myClientServer.serializeLength((username + "," + password).Length) + myClientServer.serializeString(username + "," + password);
            
            string msgFromServer = myClientServer.sendToServer(msgToSend);
            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);

            if (msgCode == constants.OK)
            {
                this.groupBox1.Hide();
                this.label1.Hide();
                this.label2.Hide();
                this.textBox1.Hide();
                this.textBox2.Hide();
                this.button1.Hide();
                this.button2.Hide();
                this.label3.Text = "Hello " + textBox1.Text;
                this.label3.Show();

                this.button2.Hide();

                this.button3.Enabled = true;
                this.button4.Enabled = true;
                this.button5.Enabled = true;
                this.button6.Enabled = true;
                this.button7.Enabled = true;
                this.button8.Enabled = true;
                button8.Show();
                constants.player_name = textBox1.Text;
                groupBox1.ForeColor = Color.Black;
            }
            else if (msgCode == constants.NOT_FOUND)
            {
                groupBox1.Text = "Username not found, try again";
                groupBox1.ForeColor = Color.Red;
            }
            else if (msgCode == constants.ALREADY_LOGGED_IN)
            {
                groupBox1.Text = "already logged in from another client";
                groupBox1.ForeColor = Color.Red;
            }
            else if(msgCode == constants.ERROR)
            {
                groupBox1.Text = "Your password is incorrect";
                groupBox1.ForeColor = Color.Red;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            /*
                sign up button event handler.
                open the sign up page(UI).
            */
            this.Hide();
            Form1 f = this as Form1;
            signUp SignUpForm = new signUp(ref f);

            SignUpForm.Show();

            

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)//username text
        {

        }

        private void label2_Click(object sender, EventArgs e)//password
        {
            
        }



        private void textBox2_TextChanged(object sender, EventArgs e)//paswword text
        {
            
        }

        private void button4_Click(object sender, EventArgs e)//create room
        {
            /*
                create room button event handler.
                open the creat room page(UI).
            */
            this.Hide();
            Form1 f = this as Form1;
            createRoom createRoomForm = new createRoom(ref f);

            createRoomForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)//join room
        {
            /*
                join room button event handler.
                gets a list of available rooms from the server, pass the list to the join room page
                and show them to the user there.

            */
            this.Hide();
            Form1 f = this as Form1;
            joinRoom joinRoomForm = new joinRoom(ref f);

            // get rooms list
            string msgToSend = myClientServer.serializeCode(4) + myClientServer.serializeLength(0);
            string msgFromServer = myClientServer.sendToServer(msgToSend);




            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            Dictionary<string, List<string>> rooms = null;

            if (msgCode == constants.OK)
            {
                
                if(length != 0)
                {


                    string response = myClientServer.binToStr(msgFromServer.Substring(40));

                    rooms = splitResp.splitRooms(response);
                    joinRoomForm.addValues(rooms.Keys.ToList());
                    // rooms format: <string roomName, list<string> players {player1, player2,...}>
                    // *note* rooms is also stored in constants static class
                }
                else
                {
                    joinRoomForm.addValues(null);
                }
                

            }
            
            joinRoomForm.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)//my status
        {
            /*
                my status button event handler.
                get user's status from the server, pass the data to the status page and show them 
                to the user there.
            */
            this.Hide();
            Form1 f = this as Form1;

            string playerName = constants.player_name;

            string msgToSend = myClientServer.serializeCode(5) + myClientServer.serializeLength(playerName.Length) + myClientServer.serializeString(playerName);//code of start game
            string msgFromServer = myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            if (msgCode == constants.OK)
            {
                string response = myClientServer.binToStr(msgFromServer.Substring(40));

                List<int> st = splitResp.splitPlayerStatus(response);
                // status format: {numOfGames, rightAnswers,WrongAnswers, AverageTime}
                // *Note* player status is also stored in constants static class.

                myStatus myStatusForm = new myStatus(ref f, st[0], st[1], st[2], st[3]);
                myStatusForm.Show();
                this.Hide();
            }

            
        }

        private void button6_Click(object sender, EventArgs e)//best scores
        {
            /*
                best scores button event handler.
                get from the server a list of the best scorers pass them to the best scorers
                page and show them to the user there.
            */
            this.Hide();
            Form1 f = this as Form1;

            string msgToSend = myClientServer.serializeCode(5) + myClientServer.serializeLength(0);
            string msgFromServer = myClientServer.sendToServer(msgToSend);

            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);
            int length = Convert.ToInt32(msgFromServer.Substring(8, 32), 2);

            if (msgCode == constants.OK)
            {
                string response = myClientServer.binToStr(msgFromServer.Substring(40));
                // now response contain 5 players max.
                // format: playername1:number,playername2:number,playername3:number
                List<Tuple<string, string>> highScores = splitResp.splitHighScores(response);
                // dictionary format <string playerName, int rightAnswers>
                // *note* the dictionary is sorted from the server.
                bestScores bestScoresForm = new bestScores(ref f, highScores);
                this.Hide();
                bestScoresForm.Show();
            }

            
        }

        private void button7_Click(object sender, EventArgs e)//quit
        {
            /*
                quit button event handler.
                exit this app.
            */
            this.Close();
        }

        /////////////////////////////////////
        private void label3_Click(object sender, EventArgs e)//hello user
        {

        }
        private void button8_Click(object sender, EventArgs e)//sign out button
        {
            /*
                sign out bitton event handler.
                send to the server a sign out query. then open the main page.
            */
            string msgToSend = myClientServer.serializeCode(2) + myClientServer.serializeLength((textBox1.Text).Length) + myClientServer.serializeString(textBox1.Text);
            string msgFromServer = myClientServer.sendToServer(msgToSend);
            int msgCode = Convert.ToInt32(msgFromServer.Substring(0, 8), 2);

            if (msgCode == constants.OK)
            {
                this.groupBox1.Show();
                this.label1.Show();
                this.label2.Show();
                this.textBox1.Show();
                this.textBox2.Show();
                this.button1.Show();
                this.button2.Show();
                this.label3.Hide();
                groupBox1.Text = "";
                
                this.button2.Show();

                this.button3.Enabled = false;
                this.button4.Enabled = false;
                this.button5.Enabled = false;
                this.button6.Enabled = false;
                this.button7.Enabled = false;
                this.button8.Enabled = false;
                label3.Hide();//hide sign out button
                label3.Text = "Hello";
            }

        }
    }


    public class clientServer
    {
        public string sendToServer(string msgToSend)
        {
            /*
                send a TCP socket to the server containing the message of the client.
                input: msgToSend:string the query to the server containing: code dataLength data
                output: responseData:string the response from the server containing: code dataLength data
            */
            TcpClient client = new TcpClient("127.0.0.1", 8876);
            Byte[] data = System.Text.Encoding.ASCII.GetBytes(msgToSend);
            NetworkStream stream = client.GetStream();

            stream.Write(data, 0, data.Length);
            data = new Byte[16384];
            String responseData = String.Empty;

            Int32 bytes = stream.Read(data, 0, data.Length);
            responseData = System.Text.Encoding.ASCII.GetString(data, 0, bytes);

            stream.Close();
            client.Close();

            return responseData;
        }

        public string serializeCode(int n)
        {
            /*
                 convert the code of the query to binary string.
                 input: n:int the code.
                 output: r:string of size 8 contain the binary display of the input.
            */
            string r = Convert.ToString(n, 2);

            while (r.Length != 8)
            {
                r = "0" + r;
            }

            return r;
        }

        public string serializeLength(int n)
        {
            /*
                 convert the query data length to binary string.
                 input: n:int the query data length.
                 output: r:string the binary display of the input of size 32
            */
            string r = Convert.ToString(n, 2);

            while (r.Length != 32)
            {
                r = "0" + r;
            }

            return r;
        }

        public string serializeString(string str)
        {
            /*
                 convert the query data to binary.
                 input: str:string the query data to be converted.
                 output: converted:string the binary display of the input in string.
            */
            string converted = "";

            foreach (char Chr in str)
            {
                converted += serializeCode(Convert.ToInt32(Convert.ToSByte(Chr)));
            }

            return converted;
        }

        public string binToStr(string binary)
        {
            /*
                 convert from binary to string.
                 input: binary:string the binary sequence in a string.
                 output: builder:string a string converted from binary.
            */
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < binary.Length; i += 8)
            {

                string section = binary.Substring(i, 8);
                int ascii = 0;
                try
                {
                    ascii = Convert.ToInt32(section, 2);
                }
                catch
                {
                    throw new ArgumentException("Binary string contains invalid section: " + section, "binary");
                }
                builder.Append((char)ascii);
            }
            return builder.ToString();
        }

    }

    public class responsesSplitting
    {
        public List<Tuple<string, string>> splitHighScores(string resp)
        {
            /*
                 convert the server response for highscores from string to list of tuples.
                 input: resp:string the response from the server.
                 output: list<tuple<playerName:string, score:string>>
            */
            List<Tuple<string, string>> high_scores_List = new List<Tuple<string, string>>();
            List<string> p = null;
            Array players = resp.Split(',').ToArray();
            Tuple<string, string> pl;

            foreach (string player in players)
            {
                p = player.Split(':').ToList();
                pl = new Tuple<string, string>(p[0], p[1]);
                high_scores_List.Add(pl);
            }

            return high_scores_List;
        }

        public Dictionary<string, List<string>> splitQuestions(string resp)
        {
            /*
                 convert the server response for questions from string to dictionary
                 input: resp:string the response from the server.
                 output: Dictionary<question:string , List<answers:string>>
            */
            Dictionary<string, List<string>> questions = new Dictionary<string, List<string>>();
            List<string> splitted = resp.Split(',').ToList();
            List<string> part = null;
            List<string> answers = null;

            string q = null;

            foreach (string question in splitted)
            {
                part = question.Split(':').ToList();

                q = part[0];
                answers = part[1].Split('|').ToList();

                questions.Add(q, answers);

            }

            return questions;
        }

        public List<int> splitPlayerStatus(string resp)
        {
            /*
                 convert the server response for player status from string to list
                 input: resp:string the response from the server.
                 output: List<scores:int>
            */
            constants.status.Clear();
            List<string> st = resp.Split(',').ToList();

            foreach(string s in st)
            {
                constants.status.Add(Convert.ToInt32(s));
            }

            return constants.status;

        }

        public Dictionary<string, List<string>> splitRooms(string resp)
        {
            /*
                 convert the server response for rooms from string to dictionary
                 input: resp:string the response from the server.
                 output: Dictionary<roomName:string, List<playerNames:string>>
            */
            List<string> roms = resp.Split(',').ToList();
            List<string> rm = null;
            List<string> plyrs = null;
            if(constants._rooms != null)
                constants._rooms.Clear();

            foreach(string rom in roms)
            {
                rm = rom.Split(':').ToList();
                plyrs = rm[1].Split(' ').ToList();

                constants._rooms.Add(rm[0], plyrs);
            }

            return constants._rooms;
        }

        public Dictionary<List<string>, List<string>> splitRoomDetails(string resp)
        {// <{TFQ, NQ}, {player1, player2}>
            /*
                 convert the server response for room details from string to dictionary
                 input: resp:string the response from the server.
                 output: Dictionary<List<detail:string>, List<playerName:string>>
                         example: <{time for question, number of questions}, {player1, player2}>
            */
            List<string> splitted = resp.Split(',').ToList();
            Dictionary<List<string>, List<string>> details = new Dictionary<List<string>, List<string>>();
            List<string> playersInRoom = new List<string>();
            
            for(int i = 2; i < splitted.Count; i++)
            {
                playersInRoom.Add(splitted[i]);
            }
            List<string> numbers = new List<string>();
            numbers.Add(splitted[0]);
            numbers.Add(splitted[1]);

            details.Add(numbers, playersInRoom);
            constants._RoomDetails = details;
            return details;
        }
    }
}

