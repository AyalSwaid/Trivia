﻿namespace WindowsFormsApp1
{
    partial class myStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.NOF = new System.Windows.Forms.Label();
            this.RA = new System.Windows.Forms.Label();
            this.WA = new System.Windows.Forms.Label();
            this.AT = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(459, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(130, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(282, 39);
            this.label1.TabIndex = 5;
            this.label1.Text = "My Performances";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "num of games";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(134, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "num of right answers";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(134, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "num of wrong answers";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(134, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "average time for answer";
            // 
            // NOF
            // 
            this.NOF.AutoSize = true;
            this.NOF.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.NOF.Location = new System.Drawing.Point(379, 92);
            this.NOF.Name = "NOF";
            this.NOF.Size = new System.Drawing.Size(15, 17);
            this.NOF.TabIndex = 10;
            this.NOF.Text = "x";
            this.NOF.Click += new System.EventHandler(this.NOF_Click);
            // 
            // RA
            // 
            this.RA.AutoSize = true;
            this.RA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.RA.Location = new System.Drawing.Point(379, 141);
            this.RA.Name = "RA";
            this.RA.Size = new System.Drawing.Size(15, 17);
            this.RA.TabIndex = 11;
            this.RA.Text = "x";
            this.RA.Click += new System.EventHandler(this.label7_Click);
            // 
            // WA
            // 
            this.WA.AutoSize = true;
            this.WA.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.WA.Location = new System.Drawing.Point(379, 180);
            this.WA.Name = "WA";
            this.WA.Size = new System.Drawing.Size(15, 17);
            this.WA.TabIndex = 12;
            this.WA.Text = "x";
            this.WA.Click += new System.EventHandler(this.label8_Click);
            // 
            // AT
            // 
            this.AT.AutoSize = true;
            this.AT.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.AT.Location = new System.Drawing.Point(379, 221);
            this.AT.Name = "AT";
            this.AT.Size = new System.Drawing.Size(15, 17);
            this.AT.TabIndex = 13;
            this.AT.Text = "x";
            // 
            // myStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 331);
            this.Controls.Add(this.AT);
            this.Controls.Add(this.WA);
            this.Controls.Add(this.RA);
            this.Controls.Add(this.NOF);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "myStatus";
            this.Text = "myStatus";
            this.Load += new System.EventHandler(this.myStatus_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label NOF;
        private System.Windows.Forms.Label RA;
        private System.Windows.Forms.Label WA;
        private System.Windows.Forms.Label AT;
    }
}